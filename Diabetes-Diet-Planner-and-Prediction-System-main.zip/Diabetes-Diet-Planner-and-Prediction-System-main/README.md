# Diabetes-Diet-Planner-and-Prediction-System
PerformedETLandEDAusingPython, reducing the features to70%usingPCAand feature selection throughchi-Squareandt-test, resulting in a3%increase in Accuracy◦Implemented various training models, includingSVM, Naive Bayes, Random Forest, Decision Trees, SVMKernel, and Logistic Regression, withRandom Forest achieving the highest accuracy of89
